"""
가족 먹여살리기
"""
from command import Command


class FeedingFamily(Command):
    def execute(self):
        pass

    def log(self):
        pass