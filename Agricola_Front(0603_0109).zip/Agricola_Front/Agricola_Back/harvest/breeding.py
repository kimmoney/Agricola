"""
동물 번식 커맨드
"""
from command import Command


class Breeding(Command):
    def execute(self):
        pass

    def log(self):
        pass