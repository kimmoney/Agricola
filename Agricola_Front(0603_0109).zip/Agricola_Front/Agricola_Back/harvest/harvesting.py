"""
작물 수확 커맨드
"""
from command import Command


class Harvesting(Command):
    def execute(self):
        pass

    def log(self):
        pass