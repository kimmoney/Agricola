from enum import Enum


class AnimalType(Enum):
    NONE = 0
    SHEEP = 1
    PIG = 2
    COW = 3
