from enum import Enum


class CropType(Enum):
    NONE = 0
    GRAIN = 1
    VEGETABLE = 2
