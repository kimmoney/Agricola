"""
채석장 라운드 행동 - 4주기
:param: 플레이어 번호
:return: 실행 결과.
:rtype: bool
"""
from command import Command


# Todo

class Stone4(Command):
    def execute(self):
        pass

    def log(self):
        pass