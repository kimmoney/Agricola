"""
집 한번 고친 후에 울타리 치기 라운드 행동
:param: 플레이어 번호
:return: 실행 결과.
:rtype: bool
"""
from command import Command


# Todo
class UpgradeFence(Command):
    def execute(self):
        pass

    def log(self):
        pass