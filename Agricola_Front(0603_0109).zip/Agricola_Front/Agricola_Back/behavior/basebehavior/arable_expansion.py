"""
밭 1개 일구기 기초 행동
:param: 플레이어 번호, 필드 상태
:return: 밭 1개 일구기 성공 여부
:rtype: bool
실제 밭 정보를 업데이트한다.
"""
from command import Command


class ArableExpansion(Command):
    def execute(self):
        pass

    def log(self):
        pass