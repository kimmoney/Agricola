"""
화로 사용 기초 행동
:param: 플레이어 번호
:return: 화로 사용 성공 여부
:rtype: bool
"""
from command import Command


class UseOven(Command):
    def execute(self):
        pass

    def log(self):
        pass