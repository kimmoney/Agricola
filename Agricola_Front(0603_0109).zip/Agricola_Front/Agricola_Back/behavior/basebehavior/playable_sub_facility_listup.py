"""
제출 가능한 보조 설비 리스트 업 함수
:param: 플레이어 번호
:return: 제출 가능한 보조 설비 리스트 반환
:rtype: list<card_name>
"""
from command import Command


class PlayableSubFacilityListup(Command):
    def execute(self):
        pass

    def log(self):
        pass