"""
집 고치기(업그레이드) 기초 행동
:param: 플레이어 번호
:return: 집 고치기 성공 여부 반환
:rtype: bool
"""
from command import Command


class HouseUpgrade(Command):
    def execute(self):
        pass

    def log(self):
        pass