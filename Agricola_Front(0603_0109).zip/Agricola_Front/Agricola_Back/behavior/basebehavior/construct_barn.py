"""
외양간 짓기 기초 행동
:param: 플레이어 번호, 변경하고자 하는 필드 상태
:return: 집 확장 성공 여부 반환
:rtype: bool
농장 상태 업데이트도 수행되어야 함.
"""
from command import Command


class ConstructBarn(Command):
    def execute(self):
        pass

    def log(self):
        pass