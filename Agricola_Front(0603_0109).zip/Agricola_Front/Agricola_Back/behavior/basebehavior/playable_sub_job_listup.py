"""
제출 가능한 직업 카드 리스트업 함수
:param: 플레이어 번호
:return: 제출 가능한 직업 카드 리스트 반환
:rtype: list<card_name>
"""
from command import Command


class PlayableSubJobListup(Command):
    def execute(self):
        pass

    def log(self):
        pass