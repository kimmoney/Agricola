"""
울타리 + 우리 생성 클래스
:param: 플레이어 번호, 변경하고자 하는 필드 상태
:return: 우리 생성 성공 여부
:rtype: bool
우리 생성 및 max 값 조정
농장 상태 업데이트도 수행되어야 함
"""
from command import Command


# Todo

class ConstructFence(Command):
    def execute(self):
        pass

    def log(self):
        pass