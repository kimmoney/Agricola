"""
구매 가능한 주요 설비 리스트업 함수
:param: void
:return: 구매 가능한 주요 설비 리스트 반환
:rtype: list<card_name>
"""
from command import Command


class PurchasableMainFacilityListup(Command):
    def execute(self):
        pass

    def log(self):
        pass