"""
병
"""
from behavior.sub_facility.sub_facility_interface import SubFacilityInterface


class Bottle(SubFacilityInterface):
    def canUse(self):
        pass

    def execute(self):
        pass

    def log(self):
        pass

    def putDown(self):
        pass
