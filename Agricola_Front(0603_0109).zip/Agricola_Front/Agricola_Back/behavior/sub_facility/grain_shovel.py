"""
곡식용 삽
"""
from behavior.sub_facility.sub_facility_interface import SubFacilityInterface


class GrainShovel(SubFacilityInterface):
    def canUse(self):
        pass

    def execute(self):
        pass

    def log(self):
        pass

    def putDown(self):
        pass
