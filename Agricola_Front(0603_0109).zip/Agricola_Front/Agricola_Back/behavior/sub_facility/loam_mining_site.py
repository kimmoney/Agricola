"""
양토 채굴장
"""
from behavior.sub_facility.sub_facility_interface import SubFacilityInterface


class LoamMiningSite(SubFacilityInterface):
    def canUse(self):
        pass

    def execute(self):
        pass

    def log(self):
        pass

    def putDown(self):
        pass
