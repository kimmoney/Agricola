"""
지붕 다지는 사람 직업 카드
"""
from behavior.job.job_interface import JobInterface


class Roofer(JobInterface):
    def canUse(self):
        pass

    def execute(self):
        pass

    def log(self):
        pass

    def putDown(self):
        pass