"""
채소 장수 직업 카드
"""
from behavior.job.job_interface import JobInterface


class Greengrocer(JobInterface):
    def canUse(self):
        pass

    def execute(self):
        pass

    def log(self):
        pass

    def putDown(self):
        pass