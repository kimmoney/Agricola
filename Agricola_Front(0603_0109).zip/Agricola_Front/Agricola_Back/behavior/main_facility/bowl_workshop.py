"""
그릇 제작소
"""
from behavior.main_facility.main_facility_interface import MainFacilityInterface


class BowlWorkshop(MainFacilityInterface):
    def execute(self):
        pass

    def log(self):
        pass

    def purchase(self):
        pass

    def canUse(self):
        pass