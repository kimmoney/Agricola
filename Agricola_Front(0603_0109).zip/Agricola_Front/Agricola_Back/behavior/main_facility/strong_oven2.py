"""
흙 5개 화덕
"""
from behavior.main_facility.main_facility_interface import MainFacilityInterface


class StrongOven2(MainFacilityInterface):
    def canUse(self):
        pass

    def execute(self):
        pass

    def log(self):
        pass

    def purchase(self):
        pass