"""
가구 제작소
"""
from behavior.main_facility.main_facility_interface import MainFacilityInterface


class FurnitureWorkshop(MainFacilityInterface):
    def canUse(self):
        pass

    def execute(self):
        pass

    def log(self):
        pass

    def purchase(self):
        pass