"""
흙 3개 화로
"""
from behavior.main_facility.main_facility_interface import MainFacilityInterface


class Oven2(MainFacilityInterface):
    def canUse(self):
        pass

    def execute(self):
        pass

    def log(self):
        pass

    def purchase(self):
        pass