"""
밭 일구기 기본 행동
:param: 플레이어 번호
:return: 실행 결과.
:rtype: bool
"""
from command import Command


# Todo

class Cultivate(Command):
    def execute(self):
        pass

    def log(self):
        pass