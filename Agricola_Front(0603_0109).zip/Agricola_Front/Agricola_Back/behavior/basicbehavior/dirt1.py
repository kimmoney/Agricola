"""
흙 채굴장
:param: 플레이어 번호
:return: 실행 결과.
:rtype: bool
"""
from command import Command


# Todo

class Dirt1(Command):
    def execute(self):
        pass

    def log(self):
        pass