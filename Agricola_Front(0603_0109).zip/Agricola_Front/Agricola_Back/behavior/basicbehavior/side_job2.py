"""
비효율 교습
:param: 플레이어 번호
:return: 실행 결과.
:rtype: bool
"""
from command import Command


# Todo

class SideJob2(Command):
    def execute(self):
        pass

    def log(self):
        pass