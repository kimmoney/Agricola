"""
회합 장소 기본 행동
:param: 플레이어 번호
:return: 실행 결과.
:rtype: bool
"""
from command import Command


# Todo

class MeetingPlace(Command):
    def execute(self):
        pass

    def log(self):
        pass