"""
점수 계산 커맨드
"""
from command import Command


class ScoreCalculation(Command):
    def execute(self):
        pass

    def log(self):
        pass