"""
게임판을 정리하는 커맨드
"""
from command import Command


class CleanGameBoard(Command):
    def execute(self):
        pass

    def log(self):
        pass