"""
라운드 행동칸 및 기본 행동칸에 자원을 쌓는 커맨드
"""
from command import Command


class StackResources(Command):
    def execute(self):
        pass

    def log(self):
        pass