"""
새 라운드 카드 공개
"""
from command import Command


class OpenNewRoundCard(Command):
    def execute(self):
        pass

    def log(self):
        pass