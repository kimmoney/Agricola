"""
게임 시작 후 초기 자원 분배 커맨드
"""
from command import Command


class StartResourceDistribution(Command):
    def execute(self):
        pass

    def log(self):
        pass