"""
카드 분배 커맨드
"""
from command import Command


class CardDistribution(Command):
    def execute(self):
        pass

    def log(self):
        pass
