"""
스킵 횟수를 체크하는 커맨드
"""
from command import Command


class HowManySkipped(Command):
    def execute(self):
        pass

    def log(self):
        pass