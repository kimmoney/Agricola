"""
undo point 를 저장하는 커맨드
"""
from command import Command


class SaveUndoPoint(Command):
    def execute(self):
        pass

    def log(self):
        pass