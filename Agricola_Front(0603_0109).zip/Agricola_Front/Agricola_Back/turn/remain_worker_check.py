"""
해당 플레이어의 남은 일꾼 수를 체크하는 커맨드
"""
from command import Command


class RemainWorkerCheck(Command):
    def execute(self):
        pass

    def log(self):
        pass